package banana;

public class MsgVO {
	
	private String boxColor;
	public String getBoxColor() { return boxColor; }
	public void setBoxColor(String boxColor) { this.boxColor = boxColor; }

	private String roomNo;
	public String getRoomNo() { return roomNo; }
	public void setRoomNo(String roomNo) { this.roomNo = roomNo; }

	private Integer no;
	public Integer getNo() { return no; }
	public void setNo(Integer no) { this.no = no; }
	
	private String username;
	public String getUsername() { return username; }
	public void setUsername(String username) { this.username = username; }
	
	private String content;
	public String getContent() { return content; }
	public void setContent(String content) { this.content = content; }
	
	private String postdate;
	public String getPostdate() { return postdate; }
	public void setPostdate(String postdate) { this.postdate = postdate; }
	
	private String showip;
	public String getShowip() { return showip; }
	public void setShowip(String showip) { this.showip = showip; }
	
	private String ofn;
	public String getOfn() { return ofn; }
	public void setOfn(String ofn) { this.ofn = ofn; }
	
	private String fsn;
	public String getFsn() { return fsn; }
	public void setFsn(String fsn) { this.fsn = fsn; }
	
}
