package banana;

public class MsgListVO {
	private String roomNo;
	public String getRoomNo() { return roomNo; }
	public void setRoomNo(String roomNo) { this.roomNo = roomNo; }
	
	private String createdate;
	public String getCreatedate() { return createdate; }
	public void setCreatedate(String createdate) { this.createdate = createdate; }
}
